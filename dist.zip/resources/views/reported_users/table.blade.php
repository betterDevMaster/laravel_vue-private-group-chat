<div class="table-responsive-sm">
    <table class="table table-striped table-bordered" id="reportedUsersTable">
        <thead>
        <th>{{ __('messages.reported_by') }}</th>
        <th>{{ __('messages.reported_to') }}</th>
        <th>{{ __('messages.reported_at') }}</th>
        <th>{{ __('messages.is_active') }}</th>
        <th>{{ __('messages.action') }}</th>
        </thead>
        <tbody></tbody>
    </table>
</div>
