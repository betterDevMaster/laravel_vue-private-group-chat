<script id="tmplNoMessagesYet" type="text/x-jsrender">
    <div id="chat-not-selected">
        <div class="chat__not-selected">
            <div class="text-center"><i class="fa fa-envelope-o" aria-hidden="true"></i></div><?php echo __('messages.no_messages_yet')?>
        </div>
    </div>
</script>
