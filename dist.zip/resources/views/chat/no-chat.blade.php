<div class="chat__not-selected">
    <div class="text-center">
        <i class="fa fa-comments font-4xl" aria-hidden="true"></i>
    </div>
    {{ __('messages.no_conversation_selected_yet') }}
</div>
