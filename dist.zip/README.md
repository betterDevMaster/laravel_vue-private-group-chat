# Laravel Chat Library
#### Steps for installation :
    1. Create .env into projets root.  
    2. Setup database information and APP_URL to .env
    3. Run `npm install`
    4. Run `php artisan key:genrate`
    5. Run `php artisan migrate`
    6. Run `npm run dev`
