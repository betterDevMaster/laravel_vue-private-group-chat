<div class="table-responsive-sm">
    <table class="table table-striped table-bordered" id="users_table">
        <thead>
        <th>{{ __('messages.profile') }}</th>
        <th>{{ __('messages.name') }}</th>
        <th>{{ __('messages.email') }}</th>
        <th>{{ __('messages.phone') }}</th>
        <th>{{ __('messages.role') }}</th>
        <th>{{ __('messages.group.privacy') }}</th>
        <th>{{ __('messages.is_active') }}</th>
        <th>{{ __('messages.action') }}</th>
        </thead>
        <tbody></tbody>
    </table>
</div>
